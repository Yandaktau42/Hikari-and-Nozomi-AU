
let gameState = "menu";
let canvas = document.getElementById("battleCanvas");
let ctx = canvas.getContext("2d");

function startGame() {
  document.getElementById("menu").style.display = "none";
  canvas.style.display = "block";
  gameState = "battle";
  requestAnimationFrame(gameLoop);
}

function openSettings() {
  document.getElementById("settings").style.display = "block";
}
function closeSettings() {
  document.getElementById("settings").style.display = "none";
}
function openCredits() {
  document.getElementById("credits").style.display = "block";
}
function closeCredits() {
  document.getElementById("credits").style.display = "none";
}

function gameLoop() {
  if (gameState !== "battle") return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // kotak pertarungan
  ctx.strokeStyle = "white";
  ctx.strokeRect(220, 300, 200, 100);

  // boss idle
  ctx.fillStyle = "white";
  ctx.font = "20px Arial";
  ctx.fillText("BOSS IDLE", 280, 100);

  // soul (heart)
  ctx.fillStyle = "red";
  ctx.beginPath();
  ctx.arc(320, 350, 10, 0, Math.PI * 2);
  ctx.fill();

  requestAnimationFrame(gameLoop);
}
